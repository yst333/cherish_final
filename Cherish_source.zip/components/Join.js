import axios from "axios";
import React, { useState } from 'react';
import '../css/login.css';
import Container from 'react-bootstrap/Container';
import Form from 'react-bootstrap/Form';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import Button from "react-bootstrap/Button";
import { Input } from "reactstrap";




const Join = () => {
  const [address, setAddress] = useState('');

  const handleDaumPostcode = () => {
    const { daum } = window;
    new daum.Postcode({
      oncomplete: (data) => {
        const fullAddress = data.address;
        setAddress(fullAddress);
      },
    }).open();
  };

    const fn_signIn = () => {
        var submitYN = false;

        const memberId = document.getElementById('memberId').value;
        const memberPw = document.getElementById('memberPw').value;

        if(document.getElementById("memberId").value.length < 1){
            alert("아이디를 입력해 주세요!");
            document.getElementById("memberId").focus()
            return;
        }

        if(document.getElementById("memberPw").value.length < 1){
            alert("비밀번호를 입력해 주세요!");
            document.getElementById("memberPw").focus()
            return;
        }

        if(!submitYN){
            var submitYN = true;

            const form = new FormData()
            form.append('memberId', memberId)
            form.append('memberPw', memberPw)

            console.log("click login");

            axios.post('http://localhost:9008/loginAction.do',
            form,{
                headers:{
                    'Content-type':'application/json',
                }
            }
            )
            .then((res) => {
                console.log(res.data);
                if(res.data != "N"){
                    alert(res.data + " 회원님, 환영합니다!");
                    // sessionStorage에 id 저장 처리함
                    sessionStorage.setItem("member_id", memberId);
                    // sessionStorage에 name 저장 처리함
                    sessionStorage.setItem("name", res.data);
                    document.location.href="/Home";
                } else{
                    alert("회원 정보가 없습니다!");
                    // 회원 가입 컴포넌트를 만들고, url을 /register로 설정했을 경우
                    // alert("회원 정보가 없습니다. 회원 가입을 해주시기 바랍니다!");
                    // document.location.href="/register";
                }
            })
            .catch()
        }

    }
    return (
        <>
          <div className="login_header">
            <p className="loginText">Join Us</p>
          </div>
      
          <Container>
            <Row className="login_row">
              <Col md={6} id="login_div1">
                <Form id="loginForm1">
                  <Form.Group className="form-group mb-1">
                    이름
                    <Input type="text" id="memberName" placeholder="" />
                  </Form.Group>
      
                  <Form.Group className="form-group mb-1">
                    생년월일
                    <Input type="date" id="birthDate" name="birthDate"  placeholder="" />
                  </Form.Group>
      
  
                  
  
  
                  <Form className="form-group mb-2">
                    성별
                        {['radio'].map((type) => (
                          <div key={`inline-${type}`} className="mb-3">
                            <Form.Check
                              inline
                              label="남성"
                              name="group1"
                              type={type}
                              id={`inline-${type}-1`}
                            />
                            <Form.Check
                              inline
                              label="여성"
                              name="group1"
                              type={type}
                              id={`inline-${type}-2`}
                            />
                          </div>
                        ))}
                  </Form>
  
  
  
  
  
      
                  <Form.Group className="form-group mb-1">
                  아이디
                    <Input
                      type="text"
                      id="memberId"
                      placeholder="영문소문자/숫자, 4~16자"
                    />
                  </Form.Group>
      
                  <Form.Group className="form-group mb-1">
                  비밀번호
                    <Input
                      type="password"
                      id="memberPassword"
                      placeholder="영문, 숫자, 특수문자 중 2가지 이상 조합, 8자 ~ 16자"
                    />
                  </Form.Group>
      
                
                  <Form.Group className="form-group mb-2">
                  비밀번호 확인
                    <Input
                      type="password"
                      id="memberPasswordConfirm"
                      placeholder=""
                    />
                  </Form.Group>
  
  
  
  
                  <Form.Group className="form-group mb-2">
                  이메일
                    <Input type="email" id="memberEmail"  placeholder="name@example.com" />
                  </Form.Group>
      
  
               
  
  
  
                </Form>
  
  
              </Col>
      
               <Col md={6} id="login_div2">
                <Form id="loginForm2">
               
      
               
      
               
      
                  <div className="btn_primary">
                      <Button  className="btn_p" onClick={handleDaumPostcode}>주소 찾기</Button>
                      <p className="address">{address}</p>
                  </div>
                    
         
      
               
      
                  <div className="agree mb-3">
                    <label>
                      <input
                        type="checkbox"
                        name="rememberMe"
                        value="yes"
                      /> 모든 약관에 동의합니다(필수 및 선택 정보) <br></br> <br></br>
                      <p className="text mb-2">
                        * 전체동의는 필수 및 선택정보에 대한 동의도 포함되며, 개별적으로도 동의를 선택하실 수 있습니다. 
                      </p>
                      <p>
                        * 선택항목에 대한 동의를 거부하는 경우에도 회원가입 서비스는 이용 가능합니다.
                      </p>
                    </label>
                  </div>
  
                  
                  <div className="mb-2">
                      <label>
                          <input type="checkbox" name="rememberMe" value="yes" /> 이용약관
                      </label>
                  </div>
                  <div className="mb-2">
                      <label>
                          <input type="checkbox" name="rememberMe" value="yes" /> 개인정보 수집 및 이용 안내
                      </label>
                  </div>
                  <div className="mb-2">
                      <label>
                          <input type="checkbox" name="rememberMe" value="yes" /> 개인정보 제3자 제공 (선택)
                      </label>
                  </div>
                  <div className="mb-2">
                      <label>
                          <input type="checkbox" name="rememberMe" value="yes" /> 개인정보 처리 위탁
                      </label>
                  </div>
  
  
               
                  <div className="line">
                      <hr />
                  </div>
  
                  <div className="mb-2">
                      <label>
                          <input type="checkbox" name="rememberMe" value="yes" /> 모든 마케팅 수신에 동의합니다 (선택)
                      </label>
                  </div>
  
                  <div className="mb-5">
                      <label>
                          <input type="checkbox" name="rememberMe" value="yes" /> 이메일 수신 동의 (선택)
                      </label>
                  </div>
  
                 
                
                
  
  
      
                  <div className="form-group d-grid mb-2">
                    <Button
                      id="id_btn"
                      variant="primary"
                      size="lg"
                      onClick={fn_signIn}
                    >
                      Join
                    </Button>
                  </div>
  
  
  
  
                </Form>
              </Col> 
            </Row>
          </Container>
        </>
      );
      
  
      };
export default Join;

