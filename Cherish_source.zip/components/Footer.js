import React from "react";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';

const url = "https://www.kcc.go.kr/user.do";

const Footer = () => {
    return(
        <>
            <div className="footerbg">
                <Container>
                <Row className="ftWrap">
                    <Col sm className="ft_catch">
                        <img src="/images/footerlogo.svg" alt="체리쉬푸터로고" />
                    </Col>
                    <Col sm className="ft_company">
                         <p className="ft_address">서울시 금천구 체리쉬로 체리쉬빌딩(06070) <br/>본 컨텐츠는 취업을 위한 포트폴리오용입니다.</p>
                         <p className="copyright">Copyright ©CHERISH All rights reserved for portfolio<br/>정보영·어예진·조수정·조윤채·유승태</p>
                    </Col>
                    <Col sm className="ft_info">
                        <div className="contact">CONTACT</div>
                            <div className="sns_bottom">
                                <light>Cherish by like this good</light><br />
                                <span className="sns">
                                    <a href="https://www.instagram.com/kkbyss/" target="_blank"><img src="/images/insta.svg" alt="인스타그램" /></a>
                                </span>
                                <span className="sns">
                                    <a href="https://twitter.com/kkbyss_official" target="_blank"><img src="/images/twitter.svg" alt="트위터" /></a>
                                </span>
                                <span className="sns">
                                    <a href="https://www.youtube.com/channel/UCfj1cHTYDjPrbGtcGKradvA" target="_blank"><img src="/images/youtube.svg" alt="유튜브" /></a>
                                </span>
                            </div>
                    </Col>
                </Row>
                    {/* <div className="ftWrap">
                        <div className="ft_catch sm">
                            <img src="/images/cherish_footerlogo.svg" alt="체리쉬푸터로고" className="height: 20px;" />
                        </div>
                        <div className="ft_company sm">
                            <p className="ft_address">서울 금천구 체리쉬로 체리쉬빌딩(06070) <br/>스타쉽ENT의 모든 컨텐츠는 저작권의 보호를 받고 있습니다.</p>
                            <p className="copyright">Copyright ©CHERISH All rights reserved for portfolio<br/>정보영·어예진·조수정·조윤채·유승태</p>
                        </div>
                        <ul className="ft_info sm">
                            <li className="contact">CONTACT</li>
                            <li className="sns_bottom">
                                <light>Cherish by like this good</light><br />
                                <span className="sns">
                                    <a href="https://www.instagram.com/kkbyss/" target="_blank"><img src="/images/insta.svg" alt="인스타그램" /></a>
                                </span>
                                <span className="sns">
                                    <a href="https://twitter.com/kkbyss_official" target="_blank"><img src="/images/twitter.svg" alt="트위터" /></a>
                                </span>
                                <span className="sns">
                                    <a href="https://www.youtube.com/channel/UCfj1cHTYDjPrbGtcGKradvA" target="_blank"><img src="/images/youtube.svg" alt="유튜브" /></a>
                                </span>
                            </li>
                        </ul>
                    </div> */}
                </Container>
            </div>
        </>
    );
};

export default Footer;