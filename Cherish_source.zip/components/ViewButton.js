import React from "react";
import Container from "react-bootstrap/esm/Container";
import { Link } from "react-router-dom";
import '../css/viewbutton.css';




const ViewButton = () => {
    return (
        <Container className="viewclontainer">
            <Link to="/Insert">
                <button className="viewBtn">게시글 등록</button>
            </Link>
            {/* <Link to="/View">
                <button className="viewBtn">최근 게시글 보기</button>
            </Link> */}
            <Link to="/Update">
                <button className="viewBtn">최근 게시글 수정</button>
            </Link>
            <Link to="/Delete">
                <button className="viewBtn">최근 게시글 삭제</button>
            </Link>
            <Link to="/boardList">
                <button className="viewBtn">게시글 상세 보기</button>
            </Link> 
        </Container>
    );
};
export default ViewButton;