import React from 'react';
import '../css/goods_item.css';


const lights = () => {
    return (
        <div>
            <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                    <img src="https://cdn-contents.weverseshop.io/public/shop/e6cc9e402037a0183c65ae2510b7626b.png" alt="뉴진스_멤버십" />
                        <section>
                            <em>Newjeans</em>
                            <p>Bunnies MEMBERSHIP</p>
                            <strong>₩25,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/ee063c155dafe65e6bfcce2aa434a2b8.png" alt="르세라핌_멤버십" />
                        <section>
                            <em>LE SSERAFIM</em>
                            <p>FEARNOT MEMBERSHIP</p>
                            <strong>₩25,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img  src="https://cdn-contents.weverseshop.io/public/shop/77031e1fda07379198dbe2d96ee16673.png" alt="에스파_멤버십" />
                        <section>
                            <em>aespa</em>
                            <p>MY MEMBERSHIP</p>
                            <strong>₩30,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/bd43870fd3853b35b128195a59dd826f.png" alt="투모로우바이투게더_멤버십" />
                        <section>
                            <em>TOMORROW X TOGETHER</em>
                            <p>MOA MEMBERSHIP</p>
                            <strong>₩17,800</strong>
                        </section>
                    </div>
                </li>
            </ul>
                       <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/c37046e43a272b70ff544da0a3fc5d47.png" alt="세븐틴_멤버십" />
                        <section>
                            <em>SEVENTEEN</em>
                            <p>CARAT MEMBERSHIP</p>
                            <strong>₩22,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/e808badb3fbc2ba4e3d4145a0c195cee.png?q=95&w=720" alt="츄_멤버십" />
                        <section>
                            <em>CHUU</em>
                            <p>KKOTI 1ST MEMBERSHIP</p>
                            <strong>₩25,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/f26fe92ad97d6787dc0da84689eaa90d.png" alt="엑소_멤버십" />
                        <section>
                            <em>EXO</em>
                            <p>EXO-L MEMBERSHIP</p>
                            <strong>₩30,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/cd89c3e7d9d2763db19ef44078a3b1b9.png" alt="스테이씨_멤버십" />
                        <section>
                            <em>STAYC</em>
                            <p>SWITH 2ND MEMBERSHIP</p>
                            <strong>₩25,000</strong>
                        </section>
                    </div>
                </li>
            </ul>
        </div>
    );
};

export default lights;