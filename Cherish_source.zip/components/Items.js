import React from 'react';
import '../css/goods_item.css';


const lights = () => {
    return (
        <div>
            <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                    <img src="	https://cdn-contents.weverseshop.io/public/shop/c88ddae445dcdc28e1a76c2e7ae40fcc.png" alt="뉴진스_굿즈" />
                        <section>
                            <em>Newjeans</em>
                            <p>PHONECASE (HIGH QUALITY) (No.2)</p>
                            <strong>₩39,800</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="	https://cdn-contents.weverseshop.io/public/shop/a313d4d097e33366ff579d952dd92ef0.png" alt="르세라핌_굿즈" />
                        <section>
                            <em>LE SSERAFIM</em>
                            <p>Ring</p>
                            <strong>₩36,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img  src="https://cdn-contents.weverseshop.io/public/shop/842ce0f202ff60caacbf3599f40a311e.png" alt="악뮤_굿즈" />
                        <section>
                            <em>AKMU</em>
                            <p>[ERROR] LEE CHANHYUK CLEAR CUP</p>
                            <strong>₩18,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/8d853067c7420bb7adeba8eae40b670d.png?q=95&w=720" alt="블랙핑크_굿즈" />
                        <section>
                            <em>BlackPink</em>
                            <p>[YOU&ME]JENNIE T-SHIRT</p>
                            <strong>₩80,000</strong>
                        </section>
                    </div>
                </li>
            </ul>
                       <ul className='GoodsUl'>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/5a2646893632fc7f09b0bcae47d45005.png" alt="세븐틴_굿즈" />
                        <section>
                            <em>SEVENTEEN</em>
                            <p>Plush Toy Set</p>
                            <strong>₩54,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/38979b05e1a9065c571ea5408512f920.png?q=95&w=720" alt="스테이씨_굿즈" />
                        <section>
                            <em>STAYC</em>
                            <p>2023 SEASON’S GREETINGS</p>
                            <strong>₩48,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/7060908bce8d9457d0884c1b180253bd.png" alt="투모로우바이투게터_굿즈" />
                        <section>
                            <em>Tomorrow x Together</em>
                            <p>Keyring</p>
                            <strong>₩20,000</strong>
                        </section>
                    </div>
                </li>
                <li className='GoodsLi'>
                    <div>
                        <img src="https://cdn-contents.weverseshop.io/public/shop/44953131edce6a69754144ee4e41d1a9.png" alt="보이넥스트도어_굿즈" />
                        <section>
                            <em>BOYNEXTDOOR</em>
                            <p>SMART TOK</p>
                            <strong>₩15,000</strong>
                        </section>
                    </div>
                </li>
            </ul>
        </div>
    );
};

export default lights;